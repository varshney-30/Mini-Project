-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: bank_mgmt
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `employee_details`
--

DROP TABLE IF EXISTS `employee_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employee_details` (
  `NAME` varchar(60) DEFAULT NULL,
  `FATHER_NAME` varchar(60) DEFAULT NULL,
  `DATE` varchar(4) DEFAULT NULL,
  `MONTH` varchar(15) DEFAULT NULL,
  `YEAR` varchar(6) DEFAULT NULL,
  `GENDER` varchar(6) DEFAULT NULL,
  `PHONE` varchar(13) DEFAULT NULL,
  `EMAIL` varchar(60) DEFAULT NULL,
  `ADDRESS` varchar(90) DEFAULT NULL,
  `CITY` varchar(38) DEFAULT NULL,
  `PIN_CODE` varchar(6) DEFAULT NULL,
  `STATE` varchar(35) DEFAULT NULL,
  `AADHAR_NUMBER` varchar(15) DEFAULT NULL,
  `PAN_NUMBER` varchar(15) DEFAULT NULL,
  `E_ID` varchar(10) NOT NULL,
  `PASSWORD` varchar(6) DEFAULT NULL,
  PRIMARY KEY (`E_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee_details`
--

LOCK TABLES `employee_details` WRITE;
/*!40000 ALTER TABLE `employee_details` DISABLE KEYS */;
INSERT INTO `employee_details` VALUES ('Harsh Agrawal','Saurabh Agrawal','25','April','2001','Male','8745699123','harshag25@gmail.com','Gular Road ','Aligarh','202001','Uttar Pradesh','789666541145','KLBH5678L','602187','6500'),('Aparna Varshney','Ashok Kumar Varshney','30','April','2001','Female','9027781675','varshneyaparna1@gmail.com','ADA Colony','Aligarh','202001','Uttar Pradesh','785261153151','BKIV6782F','623888','3004'),('Shubham Singh','Rakesh Singh','3','January','1992','Male','9974513365','shubham3@gmail.com','Kalyan Puram','Aligarh','202001','Uttar Pradesh','741258889652','LKIUY12036','70941','6226');
/*!40000 ALTER TABLE `employee_details` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-07-31 21:15:57
