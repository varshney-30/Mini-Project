
package bank_management;

import java.sql.*;

public class conn 
{
    
    public static Connection getConnection() throws SQLException
    {
        Connection con =null;
        try
        {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql:///bank_mgmt","root","Aparna_30");
            
        }catch(Exception ex)
        {
            System.out.println(ex.getMessage());
        }
        return con;
    }
    public static void main(String[] args)
    {
        new conn();
    }

    static int createStatement(int TYPE_SCROLL_INSENSITIVE, int CONCUR_UPDATABLE) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}
