/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package bank_management;

import java.awt.event.*;
import javax.swing.*;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.*;
import javax.swing.table.DefaultTableModel;
import java.text.*;
import java.awt.print.*;

public class mini_statement extends javax.swing.JFrame {
int x;
    public mini_statement() {
        //setSize(550,600);
        setResizable(false);
        setLocation(400,0);
        setVisible(true);
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        acn = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        back = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        click = new javax.swing.JButton();
        print = new javax.swing.JButton();
        clear = new javax.swing.JButton();
        date1 = new javax.swing.JTextField();
        date2 = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setFont(new java.awt.Font("Times New Roman", 1, 48)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 0, 0));
        jLabel2.setText("Mini Statement");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 10, -1, -1));

        jLabel4.setFont(new java.awt.Font("Bell MT", 1, 24)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 0, 0));
        jLabel4.setText("to");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 150, -1, -1));

        acn.setBackground(new java.awt.Color(255, 255, 255));
        acn.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        acn.setForeground(new java.awt.Color(0, 0, 0));
        acn.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                acnKeyPressed(evt);
            }
        });
        jPanel1.add(acn, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 100, 280, -1));

        jLabel5.setFont(new java.awt.Font("Bell MT", 1, 24)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(0, 0, 0));
        jLabel5.setText("Account Number");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 100, -1, -1));

        jLabel6.setFont(new java.awt.Font("Bell MT", 1, 24)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(0, 0, 0));
        jLabel6.setText("Date");
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 150, -1, -1));

        back.setBackground(new java.awt.Color(0, 0, 0));
        back.setFont(new java.awt.Font("Bell MT", 1, 24)); // NOI18N
        back.setForeground(new java.awt.Color(255, 255, 255));
        back.setText("Back");
        back.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backActionPerformed(evt);
            }
        });
        jPanel1.add(back, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 620, 100, -1));

        jTable1.setBackground(new java.awt.Color(255, 255, 255));
        jTable1.setForeground(new java.awt.Color(0, 0, 0));
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Account Number", "Date", "Deposit", "Withdraw"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(jTable1);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 280, 580, 320));

        click.setBackground(new java.awt.Color(0, 0, 0));
        click.setFont(new java.awt.Font("Bell MT", 1, 24)); // NOI18N
        click.setForeground(new java.awt.Color(255, 255, 255));
        click.setText("Click");
        click.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clickActionPerformed(evt);
            }
        });
        jPanel1.add(click, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 210, 100, -1));

        print.setBackground(new java.awt.Color(0, 0, 0));
        print.setFont(new java.awt.Font("Bell MT", 1, 24)); // NOI18N
        print.setForeground(new java.awt.Color(255, 255, 255));
        print.setText("Print");
        print.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                printActionPerformed(evt);
            }
        });
        jPanel1.add(print, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 620, 100, -1));

        clear.setBackground(new java.awt.Color(0, 0, 0));
        clear.setFont(new java.awt.Font("Bell MT", 1, 24)); // NOI18N
        clear.setForeground(new java.awt.Color(255, 255, 255));
        clear.setText("Clear");
        clear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clearActionPerformed(evt);
            }
        });
        jPanel1.add(clear, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 210, 100, -1));

        date1.setBackground(new java.awt.Color(255, 255, 255));
        date1.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        date1.setForeground(new java.awt.Color(0, 0, 0));
        date1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                date1ActionPerformed(evt);
            }
        });
        date1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                date1KeyPressed(evt);
            }
        });
        jPanel1.add(date1, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 150, 140, -1));

        date2.setBackground(new java.awt.Color(255, 255, 255));
        date2.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        date2.setForeground(new java.awt.Color(0, 0, 0));
        date2.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                date2KeyPressed(evt);
            }
        });
        jPanel1.add(date2, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 150, 140, -1));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/bank_management/WhatsApp Image 2022-04-27 at 9.24.14 PM.jpeg"))); // NOI18N
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, -250, -1, -1));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 630, 750));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void clearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clearActionPerformed
        // TODO add your handling code here:
        acn.setText("");
        date1.setText("");
        date2.setText("");
    }//GEN-LAST:event_clearActionPerformed

    private void printActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_printActionPerformed
        // TODO add your handling code here:
        MessageFormat header = new MessageFormat("Mini Statement");
        MessageFormat footer = new MessageFormat("Page{0,number,integer}");
        try
        {
            
            jTable1.print(JTable.PrintMode.NORMAL, header, footer);
            
            
        }catch(java.awt.print.PrinterException e)
        {
            System.err.format("Cannot print %s%n", e.getMessage());
        }
    }//GEN-LAST:event_printActionPerformed

    private void clickActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clickActionPerformed

        PreparedStatement ps;
        ResultSet rs;
        
        String ACN = acn.getText();
        String d1 = date1.getText();
        String d2 = date2.getText();
        
        String q = "select ACCOUNT_NUMBER from customer_details where  `ACCOUNT_NUMBER` = '"+ACN+"' " ;
        
        String q4 = "select * from bank_balance_customer where ACCOUNT_NUMBER = '"+ACN+"' and DATE >= '"+d1+"' and  DATE <= '"+d2+"' ";

        try   
        {
            conn c = new conn(); 
            ps = conn.getConnection().prepareStatement(q);
           
            rs = ps.executeQuery(q);
            if(rs.next())
            {
            ps = conn.getConnection().prepareStatement(q4);
            rs = ps.executeQuery(q4);
            DefaultTableModel model = (DefaultTableModel)jTable1.getModel();
            model.setRowCount(0);
            
            while(rs.next())
            { 
                System.out.println("4");
                model.addRow(new String[]{rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4)});   
            }  
            }
            else
            {
                JOptionPane.showMessageDialog(null, "Enter Correct Account Number");
            }
        }catch(Exception e)
        {
            System.out.println(e);
        }
    }//GEN-LAST:event_clickActionPerformed

    private void backActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backActionPerformed
        // TODO add your handling code here:
        try
        {
            if(evt.getActionCommand().equals("Back"))
            {  
                (new employee()).setVisible(true);
                this.setVisible(false);
            }
        }
        catch(Exception e)
        {
            System.out.println(e);
        }

    }//GEN-LAST:event_backActionPerformed

    private void acnKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_acnKeyPressed
        // TODO add your handling code here:
        String acc = acn.getText();
        int length = acc.length();

        char c = evt.getKeyChar();
        if(evt.getKeyChar() >= '0' && evt.getKeyChar() <= '9')
        {
            if(length < 15)
            {
                acn.setEditable(true);
            }
            else
            {
                acn.setEditable(false);
            }
        }
        else
        {
            if(evt.getExtendedKeyCode() == KeyEvent.VK_BACK_SPACE || evt.getExtendedKeyCode() == KeyEvent.VK_DELETE )
            {
                acn.setEditable(true);
            }
            else
            {
                acn.setEditable(false);
            }
        }
    }//GEN-LAST:event_acnKeyPressed

    private void date1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_date1KeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_date1KeyPressed

    private void date2KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_date2KeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_date2KeyPressed

    private void date1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_date1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_date1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(mini_statement.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(mini_statement.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(mini_statement.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(mini_statement.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new mini_statement().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField acn;
    private javax.swing.JButton back;
    private javax.swing.JButton clear;
    private javax.swing.JButton click;
    private javax.swing.JTextField date1;
    private javax.swing.JTextField date2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JButton print;
    // End of variables declaration//GEN-END:variables
}
